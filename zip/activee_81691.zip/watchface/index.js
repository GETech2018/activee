﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_font = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_font = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_icon_img = ''
        let normal_year_text_font = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_time_hour_text_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_time_minute_text_font = ''
        let normal_time_second_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Controller Ext W01 Four.ttf; FontSize: 13
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 358,
              y: 358,
              w: 286,
              h: 18,
              text_size: 13,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Controller Ext W01 Four.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Controller Ext W01 Four.ttf; FontSize: 11
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 358,
              y: 358,
              w: 241,
              h: 15,
              text_size: 11,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Controller Ext W01 Four.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Controller Ext W01 Four.ttf; FontSize: 16
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 358,
              y: 358,
              w: 345,
              h: 22,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Controller Ext W01 Four.ttf',
              color: 0xFF339966,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 360,
              h: 360,
              src: '001-fundo-principal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 227,
              y: 165,
              src: '012-pegadas.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 160,
              y: 175,
              w: 150,
              h: 30,
              text_size: 13,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Controller Ext W01 Four.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 115,
              y: 166,
              src: '011-coracao.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 46,
              y: 175,
              w: 150,
              h: 30,
              text_size: 13,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Controller Ext W01 Four.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 198,
              y: 330,
              src: '007-bloqueio.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 151,
              y: 330,
              src: '006-nao-pertube.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 167,
              y: 330,
              src: '005-bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 182,
              y: 330,
              src: '004-alarme.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 180,
              // center_y: 180,
              // start_angle: 0,
              // end_angle: 90,
              // radius: 176,
              // line_width: 24,
              // line_cap: Flat,
              // color: 0xFF339966,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 180,
              center_y: 180,
              start_angle: 0,
              end_angle: 90,
              radius: 164,
              line_width: 24,
              corner_flag: 3,
              color: 0xFF339966,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 180,
              y: -1,
              src: '003-meio-arco-bateria.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_year_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 105,
              y: 198,
              w: 150,
              h: 30,
              text_size: 11,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Controller Ext W01 Four.ttf',
              color: 0xFF808080,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 104,
              y: 297,
              week_en: ["024-seg.png","025-ter.png","026-qua.png","027-qui.png","028-sex.png","029-sab.png","030-dom.png"],
              week_tc: ["024-seg.png","025-ter.png","026-qua.png","027-qui.png","028-sex.png","029-sab.png","030-dom.png"],
              week_sc: ["024-seg.png","025-ter.png","026-qua.png","027-qui.png","028-sex.png","029-sab.png","030-dom.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 197,
              month_startY: 255,
              month_sc_array: ["013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png"],
              month_tc_array: ["013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png"],
              month_en_array: ["013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png"],
              month_zero: 1,
              month_space: -1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 187,
              month_startY: 297,
              month_sc_array: ["031-jan.png","032-fev.png","033-mar.png","034-abr.png","035-mai.png","036-jun.png","037-jul.png","040-out.png","041-nov.png","042-dez.png","038=ago.png","039=set.png"],
              month_tc_array: ["031-jan.png","032-fev.png","033-mar.png","034-abr.png","035-mai.png","036-jun.png","037-jul.png","040-out.png","041-nov.png","042-dez.png","038=ago.png","039=set.png"],
              month_en_array: ["031-jan.png","032-fev.png","033-mar.png","034-abr.png","035-mai.png","036-jun.png","037-jul.png","040-out.png","041-nov.png","042-dez.png","038=ago.png","039=set.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 98,
              day_startY: 255,
              day_sc_array: ["013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png"],
              day_tc_array: ["013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png"],
              day_en_array: ["013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png","022.png"],
              day_zero: 1,
              day_space: -2,
              day_unit_sc: '023.png',
              day_unit_tc: '023.png',
              day_unit_en: '023.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 74,
              y: 102,
              w: 150,
              h: 30,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Controller Ext W01 Four.ttf',
              color: 0xFF339966,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 136,
              y: 102,
              w: 150,
              h: 30,
              text_size: 16,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Controller Ext W01 Four.ttf',
              color: 0xFF339966,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_second_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 105,
              y: 101,
              w: 150,
              h: 30,
              text_size: 10,
              char_space: 0,
              line_space: 0,
              color: 0xFF339966,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '008-pont-hor.png',
              hour_centerX: 180,
              hour_centerY: 180,
              hour_posX: 20,
              hour_posY: 180,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '009-pont-min.png',
              minute_centerX: 180,
              minute_centerY: 180,
              minute_posX: 20,
              minute_posY: 180,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '010-pont-seg.png',
              second_centerX: 180,
              second_centerY: 180,
              second_posX: 20,
              second_posY: 180,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('year font');
              if (updateHour) {
                let normal_yearStr = timeSensor.year.toString();
                normal_year_text_font.setProperty(hmUI.prop.TEXT, normal_yearStr );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              console.log('second font');
                let normal_secondStr = second.toString();
                normal_secondStr = normal_secondStr.padStart(2, '0');
                normal_time_second_text_font.setProperty(hmUI.prop.TEXT, normal_secondStr );
            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_battery * 100);
                  if (normal_battery_circle_scale) {
                    normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 180,
                      center_y: 180,
                      start_angle: 0,
                      end_angle: 90,
                      radius: 164,
                      line_width: 24,
                      corner_flag: 3,
                      color: 0xFF339966,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0 && timeSensor.second < 2;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}