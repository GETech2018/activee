﻿    /*
    ** Watch_Face_Editor tool v 17.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_system_disconnect_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 155,
              y: 17,
              src: 'bluetooth-off-48-red.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: -44,
              y: -129,
              week_en: ["coloured-day_1.png","coloured-day_2.png","coloured-day_3.png","coloured-day_4.png","coloured-day_5.png","coloured-day_6.png","coloured-day_7.png"],
              week_tc: ["coloured-day_1.png","coloured-day_2.png","coloured-day_3.png","coloured-day_4.png","coloured-day_5.png","coloured-day_6.png","coloured-day_7.png"],
              week_sc: ["coloured-day_1.png","coloured-day_2.png","coloured-day_3.png","coloured-day_4.png","coloured-day_5.png","coloured-day_6.png","coloured-day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 26,
              hour_startY: 140,
              hour_array: ["recoloured-icon-0.png","recoloured-icon-1.png","recoloured-icon-2.png","recoloured-icon-3.png","recoloured-icon-4.png","recoloured-icon-5.png","recoloured-icon-6.png","recoloured-icon-7.png","recoloured-icon-8.png","recoloured-icon-9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 153,
              minute_startY: 140,
              minute_array: ["recoloured-icon-0.png","recoloured-icon-1.png","recoloured-icon-2.png","recoloured-icon-3.png","recoloured-icon-4.png","recoloured-icon-5.png","recoloured-icon-6.png","recoloured-icon-7.png","recoloured-icon-8.png","recoloured-icon-9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 262,
              second_startY: 166,
              second_array: ["recoloured-sec-0.png","recoloured-sec-1.png","recoloured-sec-2.png","recoloured-sec-3.png","recoloured-sec-4.png","recoloured-sec-5.png","recoloured-sec-6.png","recoloured-sec-7.png","recoloured-sec-8.png","recoloured-sec-9.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 114,
              y: 140,
              src: 'recoloured-icon-time_sep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}