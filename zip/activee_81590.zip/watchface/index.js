﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_dow_text_font = ''
        let normal_DOW_Array = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        let normal_day_month_font = ''
        let normal_timerTimeUpdate = undefined;
        let normal_stand_icon_img = ''
        let normal_stand_circle_scale = ''
        let normal_pai_icon_img = ''
        let normal_pai_circle_scale = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_circle_scale = ''
        let normal_time_hour_text_font = ''
        let normal_time_minute_text_font = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: googlesans.ttf; FontSize: 20; Cache: full
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 358,
              y: 358,
              w: 24,
              h: 24,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/googlesans.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя  ҐЄІЇґєії _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 360,
              h: 360,
              src: 'bg_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });

            normal_dow_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 80,
              y: 295,
              w: 200,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/googlesans.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // unit_string: Monday, Tuesday, Wednesday, Thursday, Friday, Saturday, Sunday,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_day_month_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 105,
              y: 35,
              w: 150,
              h: 35,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/googlesans.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 212,
              src: 'icon_stand.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 230,
              // center_y: 230,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 45,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFF176BEF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STAND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_stand_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 230,
              center_y: 230,
              start_angle: 0,
              end_angle: 360,
              radius: 39,
              line_width: 12,
              corner_flag: 0,
              color: 0xFF176BEF,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const stand = hmSensor.createSensor(hmSensor.id.STAND);
            stand.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 112,
              y: 212,
              src: 'icon_pai.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 130,
              // center_y: 230,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 45,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFF7B529,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 130,
              center_y: 230,
              start_angle: 0,
              end_angle: 360,
              radius: 39,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFF7B529,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 212,
              y: 112,
              src: 'icon_calorie.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 230,
              // center_y: 130,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 45,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFFFF3E30,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 230,
              center_y: 130,
              start_angle: 0,
              end_angle: 360,
              radius: 39,
              line_width: 12,
              corner_flag: 0,
              color: 0xFFFF3E30,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 112,
              y: 112,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 130,
              // center_y: 130,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 45,
              // line_width: 12,
              // line_cap: Rounded,
              // color: 0xFF179C52,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 130,
              center_y: 130,
              start_angle: 0,
              end_angle: 360,
              radius: 39,
              line_width: 12,
              corner_flag: 0,
              color: 0xFF179C52,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_time_hour_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 154,
              y: 55,
              w: 78,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/googlesans.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_time_minute_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 183,
              y: 55,
              w: 150,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              font: 'fonts/googlesans.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              let updateHour = timeSensor.minute == 0;

              time_update(updateHour, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0053.png',
              // center_x: 180,
              // center_y: 180,
              // x: 14,
              // y: 7,
              // start_angle: 180,
              // end_angle: 540,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 180 - 14,
              pos_y: 180 - 7,
              center_x: 180,
              center_y: 180,
              src: '0053.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0054.png',
              // center_x: 180,
              // center_y: 180,
              // x: 14,
              // y: 7,
              // start_angle: 180,
              // end_angle: 540,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 180 - 14,
              pos_y: 180 - 7,
              center_x: 180,
              center_y: 180,
              src: '0054.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '0055.png',
              // center_x: 180,
              // center_y: 180,
              // x: 9,
              // y: 24,
              // start_angle: 180,
              // end_angle: 540,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 180 - 9,
              pos_y: 180 - 24,
              center_x: 180,
              center_y: 180,
              src: '0055.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });




            //start of ignored block
            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;
              let format_hour = timeSensor.format_hour;

              console.log('day of week font');
              if (updateHour) {
                let normal_DOW_Str = normal_DOW_Array[timeSensor.week-1];
                normal_dow_text_font.setProperty(hmUI.prop.TEXT, normal_DOW_Str );
              };

              console.log('day/month font');
              if (updateHour) {
                let normal_DayStr = timeSensor.day.toString();
                let normal_MonthStr = timeSensor.month.toString();
                normal_DayStr = normal_DayStr.padStart(2, '0');
                normal_MonthStr = normal_MonthStr.padStart(2, '0');
                let normal_DayMonthStr = '--';
                const dateFormat = hmSetting.getDateFormat();
                if (dateFormat == 0 || dateFormat == 2) {
                  normal_DayMonthStr = normal_MonthStr + '/' + normal_DayStr;
                }
                if (dateFormat == 1) {
                  normal_DayMonthStr = normal_DayStr + '/' + normal_MonthStr;
                }
                normal_day_month_font.setProperty(hmUI.prop.TEXT, normal_DayMonthStr );
              };

              console.log('hour font');
              if (updateHour) {
                let normal_hourStr = format_hour.toString();
                normal_hourStr = normal_hourStr.padStart(2, '0');
                normal_time_hour_text_font.setProperty(hmUI.prop.TEXT, normal_hourStr );
              };

              console.log('minute font');
              if (updateMinute) {
                let normal_minuteStr = minute.toString();
                normal_minuteStr = normal_minuteStr.padStart(2, '0');
                normal_time_minute_text_font.setProperty(hmUI.prop.TEXT, normal_minuteStr );
              };

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 180 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 180 + normal_fullAngle_minute*(minute + second/60)/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 180 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            //end of ignored block
            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STAND');
                
                let valueStand = stand.current;
                let targetStand = stand.target;
                let progressStand = valueStand/targetStand;
                if (progressStand > 1) progressStand = 1;
                let progress_cs_normal_stand = progressStand;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_stand_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_stand * 100);
                  if (normal_stand_circle_scale) {
                    normal_stand_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 230,
                      center_y: 230,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 39,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF176BEF,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_normal_pai = progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_pai * 100);
                  if (normal_pai_circle_scale) {
                    normal_pai_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 130,
                      center_y: 230,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 39,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFF7B529,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_calorie * 100);
                  if (normal_calorie_circle_scale) {
                    normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 230,
                      center_y: 130,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 39,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFFFF3E30,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 130,
                      center_y: 130,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 39,
                      line_width: 12,
                      corner_flag: 0,
                      color: 0xFF179C52,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTimeUpdate) {
                    normal_timerTimeUpdate = timer.createTimer(0, 1000, (function (option) {
                      let updateHour = timeSensor.minute == 0;
                      let updateMinute = timeSensor.second < 2;
                      time_update(updateHour, updateMinute);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, true);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerTimeUpdate) {
                  timer.stopTimer(normal_timerTimeUpdate);
                  normal_timerTimeUpdate = undefined;
                }
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}